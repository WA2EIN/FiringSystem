﻿' (C) Copyright P. Cranwell, 2014
Public Class fTrace

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        ListBox1.Items.Clear()


    End Sub

    Private Sub fTrace_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class