﻿Public Class fDecode

    Private Sub fDecode_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class