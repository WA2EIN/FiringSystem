﻿Partial Class ShowDatabaseDataSet
End Class

Namespace ShowDatabaseDataSetTableAdapters
    
    Partial Public Class ShowEventsTableAdapter
    End Class
End Namespace
